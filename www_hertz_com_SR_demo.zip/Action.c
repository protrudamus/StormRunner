Action()
{

	//web_set_sockets_option("SSL_VERSION", "2&3");
	
	web_set_sockets_option("SSL_VERSION", "TLS1.2");

 	lr_save_timestamp("timestamp", LAST );
  	lr_output_message(lr_eval_string("{timestamp}"));
   
	web_url("reservation", 
		"URL=https://www.hertz.com/rentacar/reservation/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../assets/170110084425862/all/libs.js", ENDITEM, //170110084425862
		"Url=../assets/170110084425862/all/global.js", ENDITEM, 
		"Url=../assets/170110084425862/all/reservation/start.js", ENDITEM, 
		"Url=https://images.hertz.com/font/css/family/Ride.css", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-BoldItalic.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-Bold.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-Italic.eot?", ENDITEM, 
		LAST);

	web_url("reservation_2", 
		"URL=https://www.hertz.com/rentacar/reservation/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://images.hertz.com/font/css/family/Ride.css", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-Italic.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-BoldItalic.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-Bold.eot?", ENDITEM, 
		LAST);

	web_url("reservation_3", 
		"URL=https://www.hertz.com/rentacar/reservation/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://images.hertz.com/font/css/family/Ride.css", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-Italic.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-Bold.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-BoldItalic.eot?", ENDITEM, 
		"Url=../assets/170110084425862/all/libs.js", ENDITEM, 
		"Url=../assets/170110084425862/all/global.js", ENDITEM, 
		"Url=../assets/170110084425862/all/reservation/start.js", ENDITEM, 
		"Url=https://images.hertz.com/rac/misc/refresh09/logo_hertz_app.png", ENDITEM, 
		"Url=../member/top/navigation?_={timestamp}", ENDITEM, 
		"Url=https://images.hertz.com/rac/misc/white85p_400x400.png", ENDITEM, 
		"Url=../assets/170110084425862/reservation/homepageslide.js?_={timestamp}", ENDITEM, 
		"Url=https://images.hertz.com/rentacar/homepage/content_images/02_17_AAA_HeroBanner.jpg", ENDITEM, 
		"Url=../assets/170110084425862/omniture.js?_={timestamp}", ENDITEM, 
		"Url=https://images2.hertz.com/rac/misc/icons-s5d7d2a6aef.png", ENDITEM, 
		"Url=https://api.hertz.com/rest/content/170110084425862/IRAC/enUS/all/reservation/home/homeOverlays?callback=define", ENDITEM, 
		"Url=../assets/170110084425862/all/reservation/vehicle/style.css", ENDITEM, 
		"Url=../assets/170110084425862/all/reservation/vehicle.js", ENDITEM, 
		"Url=https://api.hertz.com/rest/content/170110084425862/IRAC/enUS/all/reservation/vehicle/vehiclePage?callback=define", ENDITEM, 
		"Url=../rest/banner/style/HomePageBanner1?v=27", ENDITEM, 
		"Url=../rest/banner/style/HomePageBanner2?v=63", ENDITEM, 
		"Url=../rest/banner/style/HomePageBanner3?v=22", ENDITEM, 
		"Url=https://images.hertz.com/rentacar/homepage/content_images/02-17-hero-hertz-ultimate-choice.jpg", ENDITEM, 
		"Url=https://images.hertz.com/rentacar/homepage/content_images/01_2017_Featured_Wknd_HeroBanner.jpg", ENDITEM, 
		"Url=../assets/css/libs/oo_style.css", ENDITEM, 
		"Url=../assets/js/libs/oo_engine.min.js?_={timestamp}", ENDITEM, 
		"Url=../assets/js/libs/oo_conf.js?_={timestamp}", ENDITEM, 
		"Url=../rest/footer/pos/US/dialect/enUS?systemId=IRAC&subSystemId=IRAC&_={timestamp}", ENDITEM, 
		"Url=https://images.hertz.com/content/dam/irac/footer/ic_youtube.png", ENDITEM, 
		"Url=https://images.hertz.com/content/dam/irac/footer/ic_google.png", ENDITEM, 
		"Url=https://images.hertz.com/content/dam/irac/footer/ic_instagram.png", ENDITEM, 
		"Url=https://images.hertz.com/content/dam/irac/footer/ic_twitter.png", ENDITEM, 
		"Url=https://images.hertz.com/rentacar/homepage/content_images/0317-hero-banner-email-sign-up.jpg", ENDITEM, 
		"Url=https://images.hertz.com/content/dam/irac/footer/ic_accessibility.png", ENDITEM, 
		"Url=https://images.hertz.com/content/dam/irac/footer/ic_facebook.png", ENDITEM, 
		"Url=../assets/js/libs/oo_engine.min.js?_={timestamp}", ENDITEM, 
		"Url=../assets/js/libs/oo_conf.js?_={timestamp}", ENDITEM, 
		"Url=https://images.hertz.com/rac/misc/refresh09/oo_icon.gif", ENDITEM, 
		"Url=https://images.hertz.com/rac/misc/refresh09/oo_icon_yellow.gif", ENDITEM, 
		LAST);

	web_url("homeOverlays.html", 
		"URL=https://www.hertz.com/rentacar/assets/170110084425862/html/all/reservation/home/homeOverlays.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_url("wordwheelMoreInfo.jsp", 
		"URL=https://www.hertz.com/rentacar/templates/integrated/locations/wordwheelMoreInfo.jsp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("homeAds.jsp", 
		"URL=https://www.hertz.com/rentacar/templates/reservation/home/homeAds.jsp?_={timestamp}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("webTracking.jsp", 
		"URL=https://www.hertz.com/rentacar/templates/framework/webTracking.jsp?targetPage=reservationOnHomepage.jsp&hashValue=itinerary&originatingUrl=https://www.hertz.com/rentacar/reservation/&_={timestamp}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("vehiclePage.html", 
		"URL=https://www.hertz.com/rentacar/assets/170110084425862/html/all/reservation/vehicle/vehiclePage.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("globalLazyLoad.jsp", 
		"URL=https://www.hertz.com/rentacar/framework/globalLazyLoad.jsp?targetPage=&_={timestamp}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../assets/images/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	return 0;
}