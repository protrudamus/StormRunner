Demo_App()
{

	web_url("RoomBallDemo", 
		"URL=http://demos.lightstreamer.com/RoomBallDemo/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://fonts.gstatic.com/s/robotocondensed/v13/Zd2E9abXLFGSr9G3YK2MsFzqCfRpIA3W6ypxnPISCPA.woff", ENDITEM, 
		"Url=css/images/ui-bg_highlight-hard_100_ffffff_1x100.png", ENDITEM, 
		"Url=css/images/ui-bg_highlight-hard_15_fafaf4_1x100.png", ENDITEM, 
		"Url=https://www.google-analytics.com/analytics.js", ENDITEM, 
		"Url=https://www.google-analytics.com/r/collect?v=1&_v=j49&a=2041026401&t=pageview&_s=1&dl=http%3A%2F%2Fdemos.lightstreamer.com%2FRoomBallDemo%2F&ul=en-us&de=iso-8859-1&dt=Lightstreamer%20Room-Ball%20Demo%20for%20JavaScript%20Client&sd=24-bit&sr=1920x1080&vp=1920x834&je=1&fl=25.0%20r0&_u=AEAAAEQAI~&jid=1238644845&gjid=1050561722&cid=1519928985.1490551427&tid=UA-11325642-1&_r=1&z=1494025664", ENDITEM, 
		"Url=images/arrow_up.png", ENDITEM, 
		"Url=images/arrow_right.png", ENDITEM, 
		"Url=images/arrow_down.png", ENDITEM, 
		"Url=images/arrow_left.png", ENDITEM, 
		"Url=images/person-03.png", ENDITEM, 
		"Url=images/ball.png", ENDITEM, 
		LAST);

	web_custom_request("create_session.js", 
		"URL=http://push.lightstreamer.com/lightstreamer/create_session.js", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/javascript", 
		"Referer=http://demos.lightstreamer.com/RoomBallDemo/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"Body=LS_op2=create&LS_phase=9801&LS_domain=lightstreamer.com&LS_cause=new.api&LS_polling=true&LS_polling_millis=0&LS_idle_millis=0&LS_cid=pcYgxn8m8 feOojyA1T661j3g2.pz479gEs&LS_adapter_set=ROOMBALL&LS_container=lsc&", 
		LAST);

	web_url("lightstreamer", 
		"URL=http://push.lightstreamer.com/lightstreamer", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");

	lr_start_transaction("Enter_Name");

	web_url("iecompatviewlist.xml", 
		"URL=https://iecvlist.microsoft.com/IE11/1426178821/iecompatviewlist.xml", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://c.urs.microsoft.com/l1.dat?v=3&cv=9.11.14393.0&os=10.0.14393.0.0&pg=4A72F430-B40C-4D36-A068-CE33ADA5ADF9", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("Enter_Name",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("Enter_Message");

	lr_end_transaction("Enter_Message",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("Clear_Message");

	lr_end_transaction("Clear_Message",LR_AUTO);

	lr_think_time(3);

	/* Exit app. */

	return 0;
}