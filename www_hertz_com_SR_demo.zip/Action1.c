Action1()
{
		web_set_sockets_option("SSL_VERSION", "2&3");

	web_set_max_html_param_len("3901");

	web_url("reservation", 
		"URL=https://www.hertz.com/rentacar/reservation/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../assets/170110084425862/all/libs.js", ENDITEM, 
		"Url=../assets/170110084425862/all/global.js", ENDITEM, 
		"Url=../assets/170110084425862/all/reservation/start.js", ENDITEM, 
		"Url=https://images.hertz.com/font/css/family/Ride.css", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-BoldItalic.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-Bold.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-Italic.eot?", ENDITEM, 
		"Url=https://fonts.googleapis.com/css?family=Muli", ENDITEM, 
		"Url=https://fonts.googleapis.com/css?family=Montserrat", ENDITEM, 
		LAST);

	web_url("reservation_2", 
		"URL=https://www.hertz.com/rentacar/reservation/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://images.hertz.com/font/css/family/Ride.css", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-Italic.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-BoldItalic.eot?", ENDITEM, 
		"Url=https://images.hertz.com/font/font/Ride/Ride-Bold.eot?", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/muli/v10/kU4XYdV4jtS72BIidPtqyw.woff", ENDITEM, 
		LAST);

/*Correlation comment - Do not change!  Original value='AKAOjstijroB2pp9iEpf7-2lpicOIAFf63pr_S9HmZOTbvrF6gGDXKfBH4B2vLEgS3hsWClGj4StyqmuEtdXkcdphZ5-8m1YxZU_j_TvcTvwt_rr8fFimgMUNosCfivmCSxzSllTNqJV-ZANC3_zfCEieb8oxBzyRXNV7JwBJShxrJ_hWGBoInMgTxwuyYuJCpRlddZPRmW6RycynC3Bh0vwT6-8S4AB2KTqEQ3HuPTPaGDaFBXi4wsFpBUulzGa40CbJM0' Name ='xai' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=xai",
		"LB=nction(){z\\x26\\x26B(C.m())}));})();\\x3c/script\\x3e\\x3cscript\\x3evu(\\x22https://securepubads.g.doubleclick.net/pcs/view?xai\\\\x3d",
		"RB=\\\\x26sig",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='Cg0ArKJSzAUYDXyM1a8CEAE' Name ='sig' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=sig",
		"LB=\\x26sig\\\\x3d",
		"RB=\\\\x26urlfix",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='CICAgKDLo7OXKxABGAEyCNTOmWZ2N9Re' Name ='id' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=id",
		"LB=src\\x3d\\x22https://tpc.googlesyndication.com/pagead/imgad?id\\x3d",
		"RB=\\x22 alt",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='B-Ez0MpjVWMiEB8mmhQbT8LHIAgAAAAAQATgByAEJwAIC4AIA4AQBoAYf' Name ='avi' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=avi",
		"LB=type\\x3d\\x22text/javascript\\x22\\x3eosdlfm(-1,\\x27\\x27,\\x27",
		"RB=\\x27,",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='CAASFeRob1xAUkiSaATh1soQTlqKAy-ifA' Name ='cid' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=cid",
		"LB=\\x27,\\x27\\x27,1880060586,true,\\x27ud\\\\x3d1\\\\x26la\\\\x3d0\\\\x26\\x27,3,\\x27",
		"RB=\\x27,",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='AKAOjsvzxy50EvMdpQtCFnjiixDPo48f5vRR8smXfxxmzwawlnneo6q1PSo-idpfC4IB3Br6kuaVblUeTbCyG8iEZJEFQuTWXaEgWX8SvYgr6Wm3WHjsT35NjLVI1ula5GEwZ7IxpmsIZlVSzzLyjvITfpBowI7BEgoQiiljncLAn8Lf4Nxy5plN3F2m53iYnqLTS8RVuCpNQGYwVq3wzd1Wp3Sh8eiP0Ta3SrqotpjVvcWglMdn6XnGCYt-taQ0gJSGp8E' Name ='xai_1' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=xai_1",
		"LB=nction(){z\\x26\\x26B(C.m())}));})();\\x3c/script\\x3e\\x3cscript\\x3evu(\\x22https://securepubads.g.doubleclick.net/pcs/view?xai\\\\x3d",
		"RB=\\\\x26sig",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='Cg0ArKJSzOpLj4xuRbOfEAE' Name ='sig_1' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=sig_1",
		"LB=\\\\x26sig\\\\x3d",
		"RB=\\\\x26urlfix",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
		"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='CICAgKDL_qfEHBABGAEyCPFI1Iw8jr8l' Name ='id_1' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=id_1",
		"LB=src\\x3d\\x22https://tpc.googlesyndication.com/pagead/imgad?id\\x3d",
		"RB=\\x22 alt",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='BFVqLMpjVWKnFD5LFhQbqxYbIBAAAAAAQATgByAEJwAIC4AIA4AQBoAYf' Name ='avi_1' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=avi_1",
		"LB=type\\x3d\\x22text/javascript\\x22\\x3eosdlfm(-1,\\x27\\x27,\\x27",
		"RB=\\x27,",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='CAASFeRo99y0QD5YqSmoQd5Fq7GZcyJRzQ' Name ='cid_1' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=cid_1",
		"LB=\\x27,\\x27\\x27,658429496,true,\\x27ud\\\\x3d1\\\\x26la\\\\x3d0\\\\x26\\x27,3,\\x27",
		"RB=\\x27,",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='AKAOjssEMKtnHUjd8rxmIyQ4G09ZL6a20bZ-g94Mo3odrmewy_FRz6VP8DxjGR6qBmxKrN1Vw9lWaUh9n_c_Zth6MbGhuUIkzkoWM6J-3IO6nZ2xESyZ7kzgXj8mocEyXW5mIJbu6l-5bD6Wcgo6AeYGz9dk8x0rKk_BxI4gcLMXKdl7fPDsPpfPWc6i0qbvZKIWgJQisSb6Sd-_6whbOMzsEucpbe5gzucBMczs5Ew57K2UnCmyRlLrnbozrv-9UZIGZVs' Name ='xai_2' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=xai_2",
		"LB=nction(){z\\x26\\x26B(C.m())}));})();\\x3c/script\\x3e\\x3cscript\\x3evu(\\x22https://securepubads.g.doubleclick.net/pcs/view?xai\\\\x3d",
		"RB=\\\\x26sig",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='Cg0ArKJSzKWyeZ70eQhKEAE' Name ='sig_2' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=sig_2",
		"LB=\\\\x26sig\\\\x3d",
		"RB=\\\\x26urlfix",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='CICAgKCLp4-1SRABGAEyCF4namhGMloE' Name ='id_2' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=id_2",
		"LB=src\\x3d\\x22https://tpc.googlesyndication.com/pagead/imgad?id\\x3d",
		"RB=\\x22 alt",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='Bo8IxMpjVWIn4FszehQaCsYNwAAAAABABOAHIAQnAAgLgAgDgBAGgBh8' Name ='avi_2' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=avi_2",
		"LB=type\\x3d\\x22text/javascript\\x22\\x3eosdlfm(-1,\\x27\\x27,\\x27",
		"RB=\\x27,",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='CAASFeRoW6a-yBspphrD8QcHg_avSesrzw' Name ='cid_2' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=cid_2",
		"LB=\\x27,\\x27\\x27,501508238,true,\\x27ud\\\\x3d1\\\\x26la\\\\x3d0\\\\x26\\x27,3,\\x27",
		"RB=\\x27,",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ads*",
			"Notfound=warning",
		LAST);

/*Correlation comment - Do not change!  Original value='5980224' Name ='src' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=src",
		"LB=x22https://",
		"RB=.fls.doubleclick.net",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/tag*",
			"Notfound=warning",
		LAST);

	web_url("reservation_3", 
		"URL=https://www.hertz.com/rentacar/reservation/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
//		EXTRARES, 
//		"Url=https://images.hertz.com/font/css/family/Ride.css", ENDITEM, 
//		"Url=https://images.hertz.com/font/font/Ride/Ride.eot?", ENDITEM, 
//		"Url=https://images.hertz.com/font/font/Ride/Ride-Italic.eot?", ENDITEM, 
//		"Url=https://images.hertz.com/font/font/Ride/Ride-Bold.eot?", ENDITEM, 
//		"Url=https://images.hertz.com/font/font/Ride/Ride-BoldItalic.eot?", ENDITEM, 
//		"Url=https://fonts.googleapis.com/css?family=Muli", ENDITEM, 
//		"Url=https://fonts.gstatic.com/s/muli/v10/kU4XYdV4jtS72BIidPtqyw.woff", ENDITEM, 
//		"Url=https://fonts.googleapis.com/css?family=Montserrat", ENDITEM, 
//		"Url=../assets/170110084425862/all/libs.js", ENDITEM, 
//		"Url=../assets/170110084425862/all/global.js", ENDITEM, 
//		"Url=../assets/170110084425862/all/reservation/start.js", ENDITEM, 
//		"Url=https://images.hertz.com/rac/misc/refresh09/logo_hertz_app.png", ENDITEM, 
//		"Url=https://fonts.gstatic.com/s/montserrat/v10/zhcz-_WihjSQC0oHJ9TCYBsxEYwM7FgeyaSgU71cLG0.woff", ENDITEM, 
//		"Url=../member/top/navigation?_=1490393132937", ENDITEM, 
//		"Url=https://images.hertz.com/rac/misc/white85p_400x400.png", ENDITEM, 
//		"Url=../assets/170110084425862/reservation/homepageslide.js?_=1490393132939", ENDITEM, 
//		"Url=https://images.hertz.com/rentacar/homepage/content_images/02_17_AAA_HeroBanner.jpg", ENDITEM, 
//		"Url=../assets/170110084425862/omniture.js?_=1490393132940", ENDITEM, 
//		"Url=https://www.googletagservices.com/tag/js/gpt.js", ENDITEM, 
//		"Url=https://images2.hertz.com/rac/misc/icons-s5d7d2a6aef.png", ENDITEM, 
//		"Url=https://api.hertz.com/rest/content/170110084425862/IRAC/enUS/all/reservation/home/homeOverlays?callback=define", ENDITEM, 
//		"Url=../assets/170110084425862/all/reservation/vehicle/style.css", ENDITEM, 
//		"Url=../assets/170110084425862/all/reservation/vehicle.js", ENDITEM, 
//		"Url=https://api.hertz.com/rest/content/170110084425862/IRAC/enUS/all/reservation/vehicle/vehiclePage?callback=define", ENDITEM, 
//		"Url=https://ssl.google-analytics.com/ga.js", ENDITEM, 
//		"Url=https://securepubads.g.doubleclick.net/gpt/pubads_impl_111.js", ENDITEM, 
//		"Url=https://ssl.google-analytics.com/r/__utm.gif?utmwv=5.6.7&utms=1&utmn=1199265709&utmhn=www.hertz.com&utmcs=utf-8&utmsr=1920x1080&utmvp=1899x834&utmsc=24-bit&utmul=en-us&utmje=1&utmfl=25.0%20r0&utmdt=Hertz%20Rent%20a%20Car%20-%20Save%20More%20on%20your%20Next%20Rental&utmhid=1374260307&utmr=-&utmp=%2Frentacar%2Freservation%2F&utmht=1490393136969&utmac=UA-20599810-1&utmcc=__utma%3D1.1878655253.1490393137.1490393137.1490393137.1%3B%2B__utmz%3D1.1490393137.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)"
//		"%7Cutmcmd%3D(none)%3B&utmjid=1741067764&utmredir=1&utmu=qhCAAAAAAAAAAAAAAAAAAAAE~", ENDITEM, 
//		"Url=https://ssl.google-analytics.com/__utm.gif?utmwv=5.6.7&utms=2&utmn=1991667884&utmhn=www.hertz.com&utmt=event&utme=5(reservationOnHomepage.jsp*ERROR*)&utmcs=utf-8&utmsr=1920x1080&utmvp=1899x834&utmsc=24-bit&utmul=en-us&utmje=1&utmfl=25.0%20r0&utmdt=Hertz%20Rent%20a%20Car%20-%20Save%20More%20on%20your%20Next%20Rental&utmhid=1374260307&utmr=-&utmp=%2Frentacar%2Freservation%2F&utmht=1490393136978&utmac=UA-20599810-1&utmcc="
//		"__utma%3D1.1878655253.1490393137.1490393137.1490393137.1%3B%2B__utmz%3D1.1490393137.1.1.utmcsr%3D(direct)%7Cutmccn%3D(direct)%7Cutmcmd%3D(none)%3B&utmjid=&utmu=6hCAAAAAAAAAAAAAQAAAAAAE~", ENDITEM, 
//		"Url=../rest/banner/style/HomePageBanner1?v=27", ENDITEM, 
//		"Url=https://securepubads.g.doubleclick.net/gampad/ads?gdfp_req=1&correlator=425143863075765&output=json_html&callback=googletag.impl.pubads.callbackProxy1&impl=fif&eid=108809080%2C108809152%2C21060118&sc=1&sfv=1-0-6&iu=%2F5246%2Fhertz.irac%2FHomePageBanner1&sz=300x250&scp=airline%3DUNKN%26cdp1%3D%26cp%3DIRAC%26dom2%3Dhttps%253A%252F%252Fwww.hertz.com%26insrep%3DN%26lang%3Den%26neverlost%3DN%26pc%3D%26posiso%3DUS%26rq%3D%26style%3DHomePageBanner1%26vehicle%3D&cookie_enabled=1&lmt=1490393137&dt="
//		"1490393137305&cc=100&frm=20&biw=1899&bih=834&oid=3&adx=1270&ady=172&adk=1880060586&gut=v2&ifi=1&u_tz=-240&u_his=1&u_java=true&u_h=1080&u_w=1920&u_ah=1030&u_aw=1920&u_cd=24&u_nplug=3&u_nmime=5&u_sd=1&flash=25.0.0&url=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F&dssz=137&icsg=3089404&vrg=111&vrp=111&ga_vid=104664622.1490393137&ga_sid=1490393137&ga_hid=1374260307", ENDITEM, 
//		"Url=../rest/banner/style/HomePageBanner2?v=63", ENDITEM, 
//		"Url=https://securepubads.g.doubleclick.net/gampad/ads?gdfp_req=1&correlator=425143863075765&output=json_html&callback=googletag.impl.pubads.callbackProxy2&impl=fif&eid=108809080%2C108809152%2C21060118&sc=1&sfv=1-0-6&iu=%2F5246%2Fhertz.irac%2FHomePageBanner2&sz=300x250&scp=airline%3DUNKN%26cdp1%3D%26cp%3DIRAC%26dom2%3Dhttps%253A%252F%252Fwww.hertz.com%26insrep%3DN%26lang%3Den%26neverlost%3DN%26pc%3D%26posiso%3DUS%26rq%3D%26style%3DHomePageBanner2%26vehicle%3D&cookie_enabled=1&lmt=1490393137&dt="
//		"1490393137572&cc=100&frm=20&biw=1899&bih=834&oid=3&adx=1270&ady=426&adk=658429496&gut=v2&ifi=2&u_tz=-240&u_his=1&u_java=true&u_h=1080&u_w=1920&u_ah=1030&u_aw=1920&u_cd=24&u_nplug=3&u_nmime=5&u_sd=1&flash=25.0.0&url=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F&dssz=138&icsg=36643836&vrg=111&vrp=111&ga_vid=104664622.1490393137&ga_sid=1490393137&ga_hid=1374260307", ENDITEM, 
//		"Url=../rest/banner/style/HomePageBanner3?v=22", ENDITEM, 
//		"Url=https://securepubads.g.doubleclick.net/gampad/ads?gdfp_req=1&correlator=425143863075765&output=json_html&callback=googletag.impl.pubads.callbackProxy3&impl=fif&eid=108809080%2C108809152%2C21060118&sc=1&sfv=1-0-6&iu=%2F5246%2Fhertz.irac%2FHomePageBanner3&sz=300x250&scp=airline%3DUNKN%26cdp1%3D%26cp%3DIRAC%26dom2%3Dhttps%253A%252F%252Fwww.hertz.com%26insrep%3DN%26lang%3Den%26neverlost%3DN%26pc%3D%26posiso%3DUS%26rq%3D%26style%3DHomePageBanner3%26vehicle%3D&cookie_enabled=1&lmt=1490393137&dt="
//		"1490393137697&cc=100&frm=20&biw=1899&bih=834&oid=3&adx=1270&ady=680&adk=501508238&gut=v2&ifi=3&u_tz=-240&u_his=1&u_java=true&u_h=1080&u_w=1920&u_ah=1030&u_aw=1920&u_cd=24&u_nplug=3&u_nmime=5&u_sd=1&flash=25.0.0&url=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F&dssz=139&icsg=170861564&vrg=111&vrp=111&ga_vid=104664622.1490393137&ga_sid=1490393137&ga_hid=1374260307", ENDITEM, 
//		"Url=https://images.hertz.com/rentacar/homepage/content_images/02-17-hero-hertz-ultimate-choice.jpg", ENDITEM, 
//		"Url=https://s.btstatic.com/tag.js", ENDITEM, 
//		"Url=https://pagead2.googlesyndication.com/pagead/osd.js", ENDITEM, 
//		"Url=https://s.thebrighttag.com/tag?site=GjmHE6C&H=xpnuss", ENDITEM, 
//		"Url=https://s.btstatic.com/lib/39f19d486acd188071ead36996d0c724d73e4dcb.js?v=2", ENDITEM, 
//		"Url=https://hertz.122.2o7.net/b/ss/hertzglobal/1/H.25.5/s95912495041832?AQB=1&pccr=true&vidn=2C6ACC1B051D2C68-60001910A000BBA9&&ndh=1&t=24%2F2%2F2017%2018%3A5%3A34%205%20240&fid=727EB7161B097FAA-1840EBC2D3CBB544&ce=UTF-8&ns=hertz&cdp=2&pageName=reservationOnHomepage.jsp&g=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F&cc=USD&ch=reservation%2F&server=www.hertz.com&v0=IRAC&events=event7&c1=Guest&c2=US&v2=US&c3=enUS&v7=arrivingInfoRadioButton&c8=Data%20Not%20Available&c9="
//		"Data%20Not%20Available&c10=Data%20Not%20Available&v16=Data%20Not%20Available%20-%20Data%20Not%20Available%20-%20Data%20Not%20Available&h1=rentacar%3Areservation&s=1920x1080&c=24&j=1.6&v=Y&k=Y&bw=1920&bh=834&p=Shockwave%20Flash%3BSilverlight%20Plug-In%3BWebEx%20Download%20Module%3B&AQE=1", ENDITEM, 
//		"Url=https://images.hertz.com/rentacar/homepage/content_images/01_2017_Featured_Wknd_HeroBanner.jpg", ENDITEM, 
//		"Url=https://www.gstatic.com/attribution/collection/attributiontools.js", ENDITEM, 
//		"Url=https://s.thebrighttag.com/tag?site=GjmHE6C&H=xpnuss&cf=152853%2C2155837%2C4167600%2C4420810%2C4658973&mode=v1", ENDITEM, 
//		"Url=../assets/css/libs/oo_style.css", ENDITEM, 
//		"Url=../assets/js/libs/oo_engine.min.js?_=1490393132941", ENDITEM, 
//		"Url=../assets/js/libs/oo_conf.js?_=1490393132942", ENDITEM, 
//		"Url=https://s.thebrighttag.com/tag?site=GjmHE6C&H=xpnuss&cf=149919%2C153330%2C153456%2C253087%2C253402%2C415835%2C2564368%2C2662930%2C2662947%2C2667133%2C2667142%2C2667177%2C2667242%2C3023155%2C3425562%2C3893400%2C4167583%2C4381314%2C4381451%2C4381815%2C4381839%2C4514472%2C4514489%2C4794762%2C4880246%2C4880271&mode=v1", ENDITEM, 
//		"Url=../rest/footer/pos/US/dialect/enUS?systemId=IRAC&subSystemId=IRAC&_=1490393132944", ENDITEM, 
//		"Url=https://images.hertz.com/content/dam/irac/footer/ic_youtube.png", ENDITEM, 
//		"Url=https://images.hertz.com/content/dam/irac/footer/ic_google.png", ENDITEM, 
//		"Url=https://images.hertz.com/content/dam/irac/footer/ic_instagram.png", ENDITEM, 
//		"Url=https://images.hertz.com/content/dam/irac/footer/ic_twitter.png", ENDITEM, 
//		"Url=https://images.hertz.com/rentacar/homepage/content_images/0317-hero-banner-email-sign-up.jpg", ENDITEM, 
//		"Url=https://images.hertz.com/content/dam/irac/footer/ic_accessibility.png", ENDITEM, 
//		"Url=https://images.hertz.com/content/dam/irac/footer/ic_facebook.png", ENDITEM, 
//		"Url=../assets/js/libs/oo_engine.min.js?_=1490393132946", ENDITEM, 
//		"Url=https://connect.facebook.net/en_US/fbds.js", ENDITEM, 
//		"Url=https://connect.facebook.net/en_US/fbevents.js", ENDITEM, 
//		"Url=../assets/js/libs/oo_conf.js?_=1490393132947", ENDITEM, 
//		"Url=https://images.hertz.com/rac/misc/refresh09/oo_icon.gif", ENDITEM, 
//		"Url=https://images.hertz.com/rac/misc/refresh09/oo_icon_yellow.gif", ENDITEM, 
//		"Url=https://apis.google.com/js/plusone.js?_=1490393132945", ENDITEM, 
//		"Url=https://www.facebook.com/tr/?id=775969495818247&ev=PixelInitialized&dl=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F&rl=&if=false&ts=1490393148031", ENDITEM, 
//		"Url=https://configusa.veinteractive.com/tags/FE478351/CC0A/4671/8F5E/00778F8E523A/tag.js", ENDITEM, 
//		"Url=https://www.facebook.com/tr/?id=1593108270902391&ev=PixelInitialized&dl=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F&rl=&if=false&ts=1490393148032", ENDITEM, 
//		"Url=https://s-cdn-tag.medialytics.com/cp", ENDITEM, 
//		"Url=https://apis.google.com/_/scs/apps-static/_/js/k=oz.gapi.en_US.fOwIphs-FXA.O/m=plusone/rt=j/sv=1/d=1/ed=1/am=AQ/rs=AGLTcCP1seaVRRZnJUZYZMYWwd68uBLZVA/cb=gapi.loaded_0", ENDITEM, 
//		"Url=https://configusa.veinteractive.com/scripts/4.20/capture-apps-4.20.0.js", ENDITEM, 
//		"Url=https://www.facebook.com/tr/?id=775969495818247&ev=PixelInitialized&dl=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F&rl=&if=false&ts=1490393148030", ENDITEM, 
//		"Url=https://www.facebook.com/tr/?id=775969495818247&ev=PixelInitialized&dl=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F&rl=&if=false&ts=1490393148033", ENDITEM, 
//		"Url=https://www.facebook.com/tr/?id=1593108270902391&ev=PixelInitialized&dl=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F&rl=&if=false&ts=1490393148035", ENDITEM, 
//		"Url=https://ad.doubleclick.net/ddm/activity/src=4708240;type=invmedia;cat=uwrv28kd;u1=;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?", ENDITEM, 
//		"Url=https://ad.doubleclick.net/activity;src=4721454;type=retar0;cat=hertz0;ord=5129334479785.557;~oref=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F;prd=", ENDITEM, 
//		"Url=https://www.facebook.com/tr/?id=1593108270902391&ev=PixelInitialized&dl=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F&rl=&if=false&ts=1490393148034", ENDITEM, 
//		"Url=https://www.facebook.com/tr/?id=583873865138057&ev=PageView&dl=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F&rl=&if=false&ts=1490393148075&v=2.7.1&a=sig&ec=0", ENDITEM, 
//		"Url=https://beacon.sojern.com/p/370?n=&fl=&", ENDITEM, 
//		"Url=https://beacon.sojern.com/pixel/p/370?n=&fl=&", ENDITEM, 
//		"Url=https://ad.doubleclick.net/ddm/activity/src=4831334;type=sales;cat=19ip6pfp;qty=1;cost=0;u1=[cid];ord=[OrderID]", ENDITEM, 
//		"Url=https://pixel.everesttech.net/3762/v?ev___loc=https%253A%252F%252Fwww.hertz.com%252Frentacar%252Freservation%252F&random=1808790907", ENDITEM, 
//		"Url=https://snap.licdn.com/li.lms-analytics/insight.min.js", ENDITEM, 
//		"Url=https://www.google.com/ads/user-lists/1055507444/?script=0&random=2407962536&fpvtc=/1055507444/%3Fvalue%3D0%26guid%3DON%26script%3D0%26random%3D347839976", ENDITEM, 
//		"Url=https://www.google.com/ads/conversion/1069042913/?value=&currency_code=&label=purchase&guid=ON&script=0&ctc_id=CAIVAgAAAB0CAAAA&ct_cookie_present=false&random=1324213717&cdct=2&convclickts=0&jaid=AJHaeXK8JZM7hjbg3MwPIXCCUYy1lAT6bpZ-JDlsAjuFeIhLiaYmb18&ebcid=ALh7CaQehpb_LDOTkVLn2-v0Roa1AKMhuo-T6jePo1HJ3fXDgTCBpDbSBKSA4TqYSLbqkdx7NTJ4FV2Z0IV02S7h8s5GAEuLUw&ocp_id=QZjVWIGKCcWLBbzvp7AP&random=3492149443&fpvtc=/1069042913/"
//		"%3Fvalue%3D%26currency_code%3D%26label%3Dpurchase%26guid%3DON%26script%3D0%26ctc_id%3DCAIVAgAAAB0CAAAA%26ct_cookie_present%3Dfalse%26jaid%3DAJHaeXK8JZM7hjbg3MwPIXCCUYy1lAT6bpZ-JDlsAjuFeIhLiaYmb18%26random%3D1307862422", ENDITEM, 
//		"Url=https://www.google.com/ads/conversion/1033191019/?value=0&currency_code=&label=f4K2CN2ljAIQ6_zU7AM&guid=ON&script=0&ctc_id=CAIVAgAAAB0CAAAA&ct_cookie_present=false&random=1548017474&cdct=2&convclickts=0&jaid=AJHaeXK8JZM7hjbg3MwPIXCCUYy1lAT6bpZ-JDlsAjuFeIhLiaYmb18&ebcid=ALh7CaQD75D5XaoEwqrWYtImHgmIHDc_YK7MJGU_z6BYLYdYzvJFmXXIcoiSEtuzO0624W8KOfTrf5mTLw6eG4D_lrpdI7i_eQ&ocp_id=QZjVWO7qJIzwBcGtqqgO&random=1169495116&fpvtc=/1033191019/"
//		"%3Fvalue%3D0%26currency_code%3D%26label%3Df4K2CN2ljAIQ6_zU7AM%26guid%3DON%26script%3D0%26ctc_id%3DCAIVAgAAAB0CAAAA%26ct_cookie_present%3Dfalse%26jaid%3DAJHaeXK8JZM7hjbg3MwPIXCCUYy1lAT6bpZ-JDlsAjuFeIhLiaYmb18%26random%3D468022569", ENDITEM, 
		LAST);

	web_url("iecompatviewlist.xml", 
		"URL=https://iecvlist.microsoft.com/IE11/1426178821/iecompatviewlist.xml", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://c.urs.microsoft.com/l1.dat?cw=636259804874493222&v=3&cv=9.11.14393.0&os=10.0.14393.0.0&pg=4A72F430-B40C-4D36-A068-CE33ADA5ADF9", "Referer=", ENDITEM, 
		LAST);

	web_url("homeOverlays.html", 
		"URL=https://www.hertz.com/rentacar/assets/170110084425862/html/all/reservation/home/homeOverlays.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("wordwheelMoreInfo.jsp", 
		"URL=https://www.hertz.com/rentacar/templates/integrated/locations/wordwheelMoreInfo.jsp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("homeAds.jsp", 
		"URL=https://www.hertz.com/rentacar/templates/reservation/home/homeAds.jsp?_=1490393133934", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("webTracking.jsp", 
		"URL=https://www.hertz.com/rentacar/templates/framework/webTracking.jsp?targetPage=reservationOnHomepage.jsp&hashValue=itinerary&originatingUrl=https://www.hertz.com/rentacar/reservation/&_=1490393132938", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("vehiclePage.html", 
		"URL=https://www.hertz.com/rentacar/assets/170110084425862/html/all/reservation/vehicle/vehiclePage.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("container.html",
		"URL=https://tpc.googlesyndication.com/safeframe/1-0-6/html/container.html",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://www.hertz.com/rentacar/reservation/",
		"Snapshot=t10.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=/pagead/imgad?id={id}", ENDITEM,
		LAST);

	web_url("view",
		"URL=https://securepubads.g.doubleclick.net/pcs/view?xai={xai}&sig={sig}&urlfix=1&adurl=",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://tpc.googlesyndication.com/safeframe/1-0-6/html/container.html",
		"Snapshot=t11.inf",
		"Mode=HTML",
		LAST);

	web_url("container.html_2", 
		"URL=https://tpc.googlesyndication.com/safeframe/1-0-6/html/container.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("container.html_3",
		"URL=https://tpc.googlesyndication.com/safeframe/1-0-6/html/container.html",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://www.hertz.com/rentacar/reservation/",
		"Snapshot=t13.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=/pagead/imgad?id={id_1}", ENDITEM,
		LAST);

	web_url("view_2",
		"URL=https://securepubads.g.doubleclick.net/pcs/view?xai={xai_1}&sig={sig_1}&urlfix=1&adurl=",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://tpc.googlesyndication.com/safeframe/1-0-6/html/container.html",
		"Snapshot=t14.inf",
		"Mode=HTML",
		LAST);

	web_url("container.html_4",
		"URL=https://tpc.googlesyndication.com/safeframe/1-0-6/html/container.html",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://www.hertz.com/rentacar/reservation/",
		"Snapshot=t15.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=/pagead/imgad?id={id_2}", ENDITEM,
		"URL=/pagead/js/r20170320/r20110914/activeview/osd_listener.js", ENDITEM,
		"URL=https://pagead2.googlesyndication.com/activeview?avi={avi}&cid={cid}&id=osdim&ti=1&adk=1880060586&mtos=1011,1011,1011,1011,1011&tos=1011,0,0,0,0&p=172,1270,422,1570&rs=3&ht=0&tfs=6&tls=1017&mc=1&lte=1&bas=0&bac=0&r=u&bs=1899,834&bos=1938,1048&ps=1899,962&ss=1920,1080&tt=1018&pt=-1&deb=1-0-3-15-5--1&tvt=1013&avms=geo&uc=4&tgt=IMG&cl=1", ENDITEM,
		"URL=https://pagead2.googlesyndication.com/activeview?avi={avi_1}&cid={cid_1}&id=osdim&ti=1&adk=658429496&mtos=1011,1011,1011,1011,1011&tos=1011,0,0,0,0&p=426,1270,676,1570&rs=3&ht=0&tfs=6&tls=1017&mc=1&lte=1&bas=0&bac=0&r=u&bs=1899,834&bos=1938,1048&ps=1899,962&ss=1920,1080&tt=1018&pt=-1&deb=1-0-3-15-5--1&tvt=1013&avms=geo&uc=4&tgt=IMG&cl=1", ENDITEM,
		"URL=https://pagead2.googlesyndication.com/activeview?avi={avi_2}&cid={cid_2}&id=osdim&ti=1&adk=501508238&mtos=0,0,1011,1011,1011&tos=0,0,1011,0,0&p=680,1270,930,1570&rs=3&ht=0&tfs=6&tls=1017&mc=0.61&lte=0.61&bas=0&bac=0&r=u&bs=1899,834&bos=1938,1048&ps=1899,962&ss=1920,1080&tt=1018&pt=-1&deb=1-0-3-15-5--1&tvt=1013&avms=geo&uc=4&tgt=IMG&cl=1", ENDITEM,
		LAST);

//	web_url("view_3",
//		"URL=https://securepubads.g.doubleclick.net/pcs/view?xai={xai_2}&sig={sig_2}&urlfix=1&adurl=",
//		"TargetFrame=",
//		"Resource=0",
//		"RecContentType=text/html",
//		"Referer=https://tpc.googlesyndication.com/safeframe/1-0-6/html/container.html",
//		"Snapshot=t16.inf",
//		"Mode=HTML",
//		LAST);

	web_url("globalLazyLoad.jsp", 
		"URL=https://www.hertz.com/rentacar/framework/globalLazyLoad.jsp?targetPage=&_=1490393132943", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../assets/images/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_url("iframeStorage.html", 
		"URL=https://configusa.veinteractive.com/scripts/shared/iframeStorage.html?iframeId=1490393151562&journeyId=2419", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.hertz.com/rentacar/reservation/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

//	web_url("activityi;src=5980224;type=reser0;cat=hertz0;ord=7581722236338.9795;~oref=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F;dc_attr=_fmt:1+chl:RElSRUNUX05BVg..+pg:aHR0cHM6Ly93d3cuaGVydHouY29tL3JlbnRhY2FyL3Jlc2VydmF0aW9uLw..+cat:aGVydHow;",
//		"URL=https://{src}.fls.doubleclick.net/activityi;src={src};type=reser0;cat=hertz0;ord=7581722236338.9795;~oref=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F;dc_attr=_fmt:1+chl:RElSRUNUX05BVg..+pg:aHR0cHM6Ly93d3cuaGVydHouY29tL3JlbnRhY2FyL3Jlc2VydmF0aW9uLw..+cat:aGVydHow;",
//		"TargetFrame=",
//		"Resource=0",
//		"RecContentType=text/html",
//		"Referer=https://www.hertz.com/rentacar/reservation/",
//		"Snapshot=t19.inf",
//		"Mode=HTML",
//		LAST);

	web_url("activityi;src=5980224;type=sitev0;cat=hertz0;ord=3200919086280.276;~oref=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F;dc_attr=_fmt:1+chl:RElSRUNUX05BVg..+pg:aHR0cHM6Ly93d3cuaGVydHouY29tL3JlbnRhY2FyL3Jlc2VydmF0aW9uLw..+cat:aGVydHow;",
		"URL=https://{src}.fls.doubleclick.net/activityi;src={src};type=sitev0;cat=hertz0;ord=3200919086280.276;~oref=https%3A%2F%2Fwww.hertz.com%2Frentacar%2Freservation%2F;dc_attr=_fmt:1+chl:RElSRUNUX05BVg..+pg:aHR0cHM6Ly93d3cuaGVydHouY29tL3JlbnRhY2FyL3Jlc2VydmF0aW9uLw..+cat:aGVydHow;",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://www.hertz.com/rentacar/reservation/",
		"Snapshot=t20.inf",
		"Mode=HTML",
		LAST);

	return 0;
}
